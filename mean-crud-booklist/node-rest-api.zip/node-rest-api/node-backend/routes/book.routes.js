const express = require('express');
const app = express();
 
const bookRoute = express.Router();
let Book = require('../model/Book');
 
// Get all Books
bookRoute.route('/').get((req, res) => {
    Book.find().then((response) => {
      res.status(200).json(response);
    })
    .catch((error) => {
      console.error(`Could not get books: ${error}`);
  })
})

// Get a single book by ID
bookRoute.route('/get-book/:id').get((req, res) => {
  const mongoose = require('mongoose');
  const bookId = req.params.id;

  // Validate Book ID
  if (!mongoose.Types.ObjectId.isValid(bookId)) {
    console.error('Invalid Book ID:', bookId);
    return res.status(400).send({ message: 'Invalid Book ID' });
  }

  console.log('Fetching book with ID:', bookId);

  // Fetch book details
  Book.findById(bookId, (err, book) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).send({ message: 'Error fetching book', error: err });
    }
    if (!book) {
      console.warn('Book not found:', bookId);
      return res.status(404).send({ message: 'Book not found' });
    }
    console.log('Book retrieved:', book);
    res.status(200).json(book);
  });
});

// Add a book
bookRoute.route('/add-book').post((req, res) => {
  Book.create(req.body).then(() => {
    console.log('Book added successfully.');
    res.status(200);
  })
  .catch((error) => {
    console.error(`Could not save book: ${error}`);
  })
})

// Update a book
bookRoute.route('/update-book/:id').put((req, res) => {
  Book.findByIdAndUpdate(req.params.id, { $set: req.body })
    .then(() => {
      console.log('Book updated successfully.');
      res.status(200).send('Book updated successfully.');
    })
    .catch(error => {
      console.error(`Could not update book: ${error}`);
      res.status(500).send('Error updating book.');
    })
})

// Delete a book
bookRoute.route('/delete-book/:id').delete((req, res) => {
  console.log(`Preparing to delete: ${req.params.id}`);
  Book.findByIdAndDelete(req.params.id).then(() => {
    console.log('Book deleted successfully.');
  })
  .catch((error) => {
    console.error(`Could not delete book: ${error}`);
  })
})

module.exports = bookRoute;