import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CrudService } from 'src/app/service/crud.service';

@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent implements OnInit {
  bookForm: FormGroup;
  bookId: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private crudService: CrudService
  ) {
    this.bookForm = this.formBuilder.group({
      isbn: [''],
      title: [''],
      author: [''],
      description: [''],
      published_year: [''],
      publisher: ['']
    });
    this.bookId = this.route.snapshot.paramMap.get('id') || '';
  }

  ngOnInit(): void {
    this.crudService.GetBook(this.bookId).subscribe({
      next: (data: any) => {
        if (data) {
          console.log('Book details retrieved:', data);
          this.bookForm.setValue({
            isbn: data.isbn,
            title: data.title,
            author: data.author,
            description: data.description,
            published_year: data.published_year,
            publisher: data.publisher
          });
        } else {
          console.error('No data found for the given book ID.');
        }
      },
      error: (error: any) => {
        console.error('Error fetching book details:', error);
      }
    });
  }
  

  onSubmit(): void {
    this.crudService.UpdateBook(this.bookId, this.bookForm.value).subscribe(() => {
      console.log('Book updated successfully')
      this.router.navigate(['/books-list']);
    }, (error: any) => {
      console.error('Error updating book:', error);
    });
  }
}
